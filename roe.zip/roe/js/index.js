


$('#roe-top-nav a').click(function (e) {
  e.preventDefault()
  $(this).tab('show')
})


webshims.setOptions('forms-ext', {
    replaceUI: 'auto',
    types: 'number',
    "widgets": {
        "calculateWidth": false
    }
});
webshims.polyfill('forms forms-ext');

$('#b10').change(function (e) {
  e.preventDefault();
  updatePayPeriods();
});

$('#b12').change(function (e) {
  e.preventDefault();
  updatePayPeriods();
});

$('#b6').change(function (e) {
  e.preventDefault();
  updatePayPeriods();
});

$("input[name=b2-yes-no]:radio").change(function (e) {
	e.preventDefault();
	if( $(this).val() == 'Y' ){
		$('#b2-group').show();
	}else{
		$('#b2-group').hide();
		$('#b2').val("");
	}
});

$('#b14-cd').change(function (e) {
  e.preventDefault();
  if( $(this).val() == 'Y' ){
		$('#b14-dt-group').show();
	}else{
		$('#b14-dt-group').hide();
		$('#b14-dt').val("");
	}
});

$('.lang-switch').click(function(e) {
	e.preventDefault();
	$.i18n().locale = $(this).data('locale');
	update_texts();
});

var update_texts;

jQuery(document).ready(function() {

 	update_texts = function() {
		$('body').i18n();
	};

	// Enable debug
	$.i18n.debug = true;

	$.i18n().load({
		en: {
			"appname-title": "Record of Employment (ROE)",
			"employer-info": "Employer Information",
			"reason-for-issue": "Reason for issuing this ROE"
		},
		fr: {
			"appname-title": "Relevés d'emploi (RE)",
			"employer-info": "Information de l'employeur",
			"reason-for-issue": "Raison du présent relevé d'emploi"
		}
	});

	update_texts();
});




function updatePayPeriods(){
	
	try{
		var firstDayWorked = $("#b10").val();
		var finalPayPeriod = $("#b12").val();
		var frequency = $("#b6").val(); 

		if( firstDayWorked == "" || finalPayPeriod == "" || frequency == "" ){
			$('#pay-periods').html( "" );
			$("#complete-pp-info").show();
			$("#pp-info").hide();
			$("#total-insurables").hide();
			return 0;
		}

		var date1 = new Date( firstDayWorked );
		var date2 = new Date( finalPayPeriod );
		var timeDiff = date2.getTime() - date1.getTime();

		if( timeDiff < 0 ){
			alert( "Bad Dates" );
			return 0;
		}

		var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 

		var daysInPeriod = 1;
		var maxPeriods = 0;
		switch( frequency ){
			case 'B': 
				daysInPeriod = 14;
				maxPeriods = 27;
				break;
			case 'E':
				daysInPeriod = 14;
				maxPeriods = 25;
				break;
			case 'H':
				daysInPeriod = 28;
				maxPeriods = 14;
				break;
			case 'M':
				daysInPeriod = 30;
				maxPeriods = 13;
				break;
			case 'O':
				daysInPeriod = 30;
				maxPeriods = 13;
				break;
			case 'S':
				daysInPeriod = 15;
				maxPeriods = 25;
				break;
			case 'W':
				daysInPeriod = 7;
				maxPeriods = 53;
				break;
		}

		var periods = Math.ceil(diffDays / daysInPeriod);

		if( periods > maxPeriods ){
			periods = maxPeriods;
		}
		
		if( periods == 0 ){
			$('#pay-periods').html( "" );
			$("#complete-pp-info").show();
			$("#pp-info").hide();
			$("#total-insurables").hide();

		}else{
			$("#complete-pp-info").hide();
			$("#pp-info").show();
			$("#total-insurables").show();
			writePayPeriods(periods, finalPayPeriod, daysInPeriod);
		}
	}catch(e){
		console.log(e);
	}
}


function writePayPeriods( numOfPeriods, finalPayPeriod, daysInPeriod ){

	try{
		var html = '<div class="row">';

		var inputDate = new Date(finalPayPeriod);
		//fix the timezone offsets otherwise the date is off by one day
		var ppEndDate = new Date( inputDate.getTime() - inputDate.getTimezoneOffset() * -60000 )

		console.log( ppEndDate );
		for (var i = 0; i < numOfPeriods; i++ ){

			if( i > 0 && i % 2 == 0 ){
				html += '<div class="row">';
			}

			html += writePayPeriod( i + 1, ppEndDate.getFullYear() + "-" + expandNum(ppEndDate.getMonth() + 1) + "-" + expandNum(ppEndDate.getDate()) );

			if( i > 0 && i < numOfPeriods - 1 && i % 2 == 1 ){
				html += '</div>';
			}

			ppEndDate.setDate(ppEndDate.getDate()-daysInPeriod);
		}

		html += '</div>';
		console.log(html);
		$('#pay-periods').html( html );
		$('#pay-periods-number').html( numOfPeriods );

		for (var i = 0; i < numOfPeriods; i++ ){
			$("#b15c-" + (i + 1) + "-edt").datepicker({format: "yyyy-mm-dd"});
		}
	}catch(e){
		console.log(e);
	}
}

function expandNum( num ){
	return ("0" + num).slice(-2);
}

function writePayPeriod( period, date ){
	var html = '';
	html +='			<div class="col-lg-6 col-md-6">\n';
	html +='				<div class="panel panel-default panel-tighten" id="b15c-' + period + '-edt-panel">\n';
	html +='					<div class="panel-heading">\n';
	html +='						<b>Pay Period ' + period + '</b>\n';
	html +='					</div>\n';
	html +='					<div class="panel-body">\n';
	html +='						<div class="row">\n';
	html +='							<div class="col-lg-3 col-md-3">\n';
	html +='								 <div class="form-group" id="b15c-' + period + '-edt-group">\n';
	html +='									<label class="control-label" for="b15c-' + period + '-edt">\n';
	html +='										End Date\n';
	html +='										<a data-toggle="modal" data-target="#b15c-edt-help">\n';
	html +='											<span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span>\n';
	html +='										</a>\n';
	html +='									</label>\n';
	html +='									<input type="text" class="form-control" id="b15c-' + period + '-edt" placeholder="'+ date +'" required>\n';
	html +='								</div>\n';
	html +='							</div>\n';
	html +='							<div class="col-lg-5 col-md-5">\n';
	html +='								 <div class="form-group" id="b15c-' + period + '-amt-group">\n';
	html +='									<label class="control-label" for="b15c-' + period + '-amt">\n';
	html +='										Insurable Earnings\n';
	html +='										<a data-toggle="modal" data-target="#b15c-amt-help">\n';
	html +='											<span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span>\n';
	html +='										</a>\n';
	html +='									</label>\n';
	html +='									<div class="input-group">\n';
	html +='										<span class="input-group-addon">\n';
	html +='											<span class="glyphicon glyphicon-usd" aria-hidden="true"></span>\n';
	html +='										</span>\n';
	html +='										<input type="number" value="0" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100" class="form-control currency" id="b15c-' + period + '-amt"required>\n';
	html +='									</div>\n';
	html +='								</div>\n';
	html +='							</div>\n';
	html +='							<div class="col-lg-4 col-md-4">\n';
	html +='								 <div class="form-group" id="b15c-' + period + '-hrs-group">\n';
	html +='									<label class="control-label" for="b15c-' + period + '-hrs">\n';
	html +='										Insurable Hours\n';
	html +='										<a data-toggle="modal" data-target="#b15c-hrs-help">\n';
	html +='											<span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span>\n';
	html +='										</a>\n';
	html +='									</label>\n';
	html +='									<div class="input-group">\n';
	html +='										<span class="input-group-addon">\n';
	html +='											<span class="glyphicon glyphicon-time"></span>\n';
	html +='										</span>\n';
	html +='										<input type="number" value="0" min="0" step="0.01" data-number-to-fixed="2" data-number-stepfactor="100" class="form-control currency" class="form-control" id="b15c-' + period + '-hrs" required>\n';
	html +='									</div>\n';
	html +='								</div>\n';
	html +='							</div>\n';
	html +='						</div>\n';
	html +='					</div>\n';
	html +='				</div>\n';
	html +='			</div>\n';

	return html;
}